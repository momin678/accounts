<h2>Hello Admin,</h2>
You received an email from : <?php echo e($name); ?><br>
Here are the details:<br>
<b>Name:</b> <?php echo e($name); ?><br>
<b>Email:</b> <?php echo e($email); ?><br>
<b>Phone Number:</b> <?php echo e($phone_number); ?><br>
<b>Subject:</b> <?php echo e($subject); ?><br>
<b>Message:</b> <?php echo e($user_message); ?><br><br><br>
Thank You<?php /**PATH /home/datagate/accounts.datagatebd.com/resources/views/contact_email.blade.php ENDPATH**/ ?>