<?php
    use App\Models\User;
    $totalPermissnion = User::checkPermission();
?>

<?php $__env->startSection('css'); ?>
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css' )); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css' )); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css' )); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
          
        <div class="text-left mb-3">
            <div class="row align-items-center">
                <div class="col-auto">
                    <h1 class="h3">All Staff</h1>
                </div>
                <?php if(Auth::user()->user_type == 'admin' || in_array('1',$totalPermissnion,) && Auth::user()->user_type == 'staff'): ?>
                <div class="col text-right">
                    <a href="<?php echo e(route('staff.create')); ?>" class="btn btn-circle btn-info">
                        <span>Add New Staff</span>
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php echo $__env->make('errors.error_massege', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
          <div class="col-12">

            <div class="card mt-3">
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Staff Name</th>
                        <th scope="col">Staff Email</th>
                        <th scope="col">Role Name</th>
                        <th scope="col">Extra Permission</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                  <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($loop->index+1); ?></th>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <?php
                                $staff_id = \App\Models\Staff::getStaffId($user->id);
                                if($staff_id){
                                    $roles_id = json_decode($staff_id->role_id);
                                    if($roles_id){
                                        for($i=0; $i<count($roles_id); $i++){
                                            $role_id = \App\Models\Staff::getRoleName($roles_id[$i]);
                                            echo "<p class='badge badge-info mr-1'>".$role_id->name."</p>";
                                        }
                                    }
                                }
                            ?>
                        </td>
                        <td>
                        <?php
                            $staff_id = \App\Models\Staff::getStaffId($user->id);
                            if($staff_id){
                                $permissions_id = json_decode($staff_id->permission_id);
                                if($permissions_id){
                                    for($i=0; $i<count($permissions_id); $i++){
                                        $permission_id = \App\Models\Staff::getPermissionName($permissions_id[$i]);
                                        echo "<p class='badge badge-info mr-1'>".$permission_id->name."</p>";
                                    }
                                }
                            }
                        ?>
                        </td>
                        <td class="d-flex justify-content-center">
                            <?php if(Auth::user()->user_type == 'admin' || in_array('3',$totalPermissnion,) && Auth::user()->user_type == 'staff'): ?>
                            <a href="<?php echo e(route('staff.edit', $user->id)); ?>" type="button" class="btn btn-info mr-2">Edit</a>
                            <?php endif; ?>
                            <?php if(Auth::user()->user_type == 'admin' || in_array('4',$totalPermissnion,) && Auth::user()->user_type == 'staff'): ?>
                            <a class="btn btn-danger text-white" href="<?php echo e(route('staff.destroy', $user->id)); ?>"
                                onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($user->id); ?>').submit();">
                                    Delete
                            </a>
                            <form id="delete-form-<?php echo e($user->id); ?>" action="<?php echo e(route('staff.destroy', $user->id)); ?>" method="POST" style="display: none;">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- DataTables  & Plugins -->
<script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/dataTables.responsive.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/dataTables.buttons.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jszip/jszip.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/pdfmake/pdfmake.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/pdfmake/vfs_fonts.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.html5.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.print.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.colVis.min.js' )); ?>"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datagate/accounts.datagatebd.com/resources/views/backend/staffs/staff/index.blade.php ENDPATH**/ ?>