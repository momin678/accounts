
<?php $__env->startSection('content'); ?>
<style>
    .form-check-label {
        text-transform: capitalize;
    }
    .bg_color{
        background-color: #98d4c463 !important;
    }
</style>
<div class="aiz-titlebar text-left mb-3">
    <div class="row align-items-center">
        <div class="col-auto">
            <h1 class="h3">New Staff Add</h1>
        </div>
        <div class="col text-right">
            <a href="<?php echo e(route('staff.index')); ?>" class="btn btn-circle btn-info">
                <span>Return Back</span>
            </a>
        </div>
    </div>
</div>
<?php echo $__env->make('errors.error_massege', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card">
    <form action="<?php echo e(route('staff.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Staff Name</label>
                        <input type="text" class="form-control" id="" placeholder="Staff name" name='name' >
                    </div>
                    <div class="form-group">
                        <label>Staff Email</label> 
                        <input class="form-control" type="email" id="" name='email' placeholder="Staff email" >
                    </div>
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="text" class="form-control" id="" placeholder="Staff number" name='number' >
                    </div>
                    <div class="form-group">
                        <label>Staff password</label> 
                        <input class="form-control" type="password" id="" name='password'  placeholder="password">
                    </div>
                    <div class="form-group">
                        <label>Staff Role</label>
                        <select class="form-control multiple_select" multiple name="role_id[]">
                            <?php $__currentLoopData = $all_permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-8">
                    <label>Extra-permission</label> 
                    <div class="row">
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $all_permission_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $permissions = App\Models\Permission::getpermissionsNameByGroupName($group->id);
                            $j = 1;
                        ?>
                            <div class="col-md-6 pr-3 pb-2">
                                <div class="row">
                                    <div class="col-md-4 ">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="<?php echo e($i); ?>Management" value="<?php echo e($group->name); ?>" onclick="checkPermissionByGroup('role-<?php echo e($i); ?>-management-checkbox', this)">
                                            <label class="form-check-label" for="<?php echo e($i); ?>Management"><?php echo e($group->name); ?></label> 
                                        </div>
                                    </div>
                                    <div class="col-md-8 role-<?php echo e($i); ?>-management-checkbox bg_color">
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check ">
                                            <input class="form-check-input" 
                                            type="checkbox" id="rolePermission<?php echo e($permission->id); ?>" 
                                            value="<?php echo e($permission->id); ?>" name="permission_id[]"
                                            onclick="checkSignPermission('role-<?php echo e($i); ?>-management-checkbox', '<?php echo e($i); ?>Management', <?php echo e(count($permissions)); ?>)"
                                            >
                                            <label class="form-check-label" for="rolePermission<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></label> 
                                        </div>
                                        <?php $j++ ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>            
                                </div>            
                            </div>
                        <?php $i++ ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Data Save</button>
        </div>    
    </form>
</div>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>
<?php echo $__env->make('partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datagate/accounts.datagatebd.com/resources/views/backend/staffs/staff/create.blade.php ENDPATH**/ ?>