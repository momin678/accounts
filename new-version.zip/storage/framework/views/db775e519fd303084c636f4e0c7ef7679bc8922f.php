<?php
    use App\Models\User;
    $totalPermissnion = User::checkPermission();
?>

<?php $__env->startSection('css'); ?>
<style>
.editForm{
    display: none;
}
.nopadding {
    padding-left: 4px !important;
    padding-right: 4px !important;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="aiz-titlebar text-left mb-3">
        <div class="row align-items-center">
            <div class="col-auto">
                <h1 class="h3">All Permission</h1>
            </div>
            <?php if(Auth::user()->user_type == 'admin' || in_array('29', $totalPermissnion)): ?>
            <div class="col text-right">
                <a href="<?php echo e(route('permission.create')); ?>" class="btn btn-circle btn-info">
                    <span>Add New Permission</span>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php echo $__env->make('errors.error_massege', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <?php $__currentLoopData = $permissions_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $permissions = App\Models\Permission::where('group_id',$group->id)->get();
        ?>
        <div class="col-md-4 p-3 ">
            <div class="row card">
                <div class="card-header nopadding">
                    <div class="form-check mb-3">
                        <label class="form-check-label text-capitalize" for=""><span class="badge badge-info mr-1"><?php echo e($group->id); ?> </span> <?php echo e($group->name); ?></label>
                        <?php if(Auth::user()->user_type == 'admin' || in_array(32, $totalPermissnion)): ?>
                        <a href="<?php echo e(route('permission-group-delete',$group->id)); ?>" class="btn btn-danger btn-sm  float-right"> Delete </a>
                        <?php endif; ?>
                        <!--<a href="<?php echo e(route('permission-group-edit',$group->id)); ?>" class="btn btn-info btn-sm float-right mr-2"> Edit</a>-->
                    </div>
                    <?php if(Auth::user()->user_type == 'admin' || in_array('29', $totalPermissnion)): ?>
                      <form method="post" action="<?php echo e(route('permission.add', $group->id)); ?>">
                          <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input type="text" name="name" class="form-control m-input" placeholder="Add permission like category.edit" autocomplete="off">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-primary">Add</button>
                            </div>
                        </div>
                    </form>
                    <?php endif; ?>
                </div>
                <div class="card-body nopadding">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check mb-1">
                        <label class="form-check-label m-1"><span class="badge badge-info mr-1"><?php echo e($permission->id); ?> </span> <?php echo e($permission->name); ?></label>
                        <?php if(Auth::user()->user_type == 'admin' || in_array(32, $totalPermissnion)): ?>
                        <a class="btn btn-danger btn-sm  float-right" href="<?php echo e(route('permission.destroy', $permission->id)); ?>"
                            onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($permission->id); ?>').submit();">
                                Delete
                        </a>
                        <form id="delete-form-<?php echo e($permission->id); ?>" action="<?php echo e(route('permission.destroy', $permission->id)); ?>" method="POST" style="display: none;">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                        </form>
                        <?php endif; ?>
                        <?php if(Auth::user()->user_type == 'admin' || in_array(30, $totalPermissnion)): ?>
                        <button type="submit" class="btn btn-primary  btn-sm  float-right edit_id mr-1" id="<?php echo e($permission->id); ?>">Edit</button>
                        <form id="form<?php echo e($permission->id); ?>" action="<?php echo e(route('permission.update', $permission->id)); ?>" method="POST" class="editForm">
                            <?php echo method_field("PUT"); ?>
                            <?php echo csrf_field(); ?>
                            <div class="input-group mb-1 mt-1">
                                <input type="text" name="permissionName" class="form-control m-input" value="<?php echo e($permission->name); ?>" autocomplete="off">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                        <?php endif; ?>
                    </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>            
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $("button").click(function(){
            let id = $(this).attr('id');
            $("#form"+id).show();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datagate/accounts.datagatebd.com/resources/views/backend/staffs/permission/index.blade.php ENDPATH**/ ?>