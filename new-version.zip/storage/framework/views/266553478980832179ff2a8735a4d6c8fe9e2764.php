
<?php $__env->startSection('content'); ?>
<div class="aiz-titlebar text-left mb-3">
    <div class="row align-items-center">
        <div class="col-auto">
            <h1 class="h3">New Permission Add</h1>
        </div>
        <div class="col text-right">
            <a href="<?php echo e(route('permission.index')); ?>" class="btn btn-circle btn-info">
                <span>Return Back</span>
            </a>
        </div>
    </div>
</div>
<?php echo $__env->make('errors.error_massege', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card">
    <form action="<?php echo e(route('permission.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row card-body">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="groupName">Group Name</label>
                    <input type="text" class="form-control" id="groupName" placeholder="Group Name like Category" name='name' >
                </div>
                <div class="form-group">
                    <label for="permissionCreate">Permission Creaete</label>
                    <input type="text" class="form-control" id="permissionCreate" placeholder="like category.creaete" name='permissionName[]' >
                </div>
                <div class="form-group">
                    <label for="permissionEdit">Permission Edit</label>
                    <input type="text" class="form-control" id="permissionEdit" placeholder="like category.edit" name='permissionName[]' >
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="permissionView">Permission View</label>
                    <input type="text" class="form-control" id="permissionView" placeholder="like category.view" name='permissionName[]' >
                </div>
                <div class="form-group">
                    <label for="permissionDelete">Permission Delete</label>
                    <input type="text" class="form-control" id="permissionDelete" placeholder="like category.delete" name='permissionName[]' >
                </div>
                <div class="form-group">
                    <label for="permissionApprove">Permission Approve</label>
                    <input type="text" class="form-control" id="permissionApprove" placeholder="like category.approve " name='permissionName[]' >
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Data Save</button>
        </div>    
    </form>
</div>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datagate/accounts.datagatebd.com/resources/views/backend/staffs/permission/create.blade.php ENDPATH**/ ?>