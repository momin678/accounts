<?php
    use App\Models\User;
    $totalPermissnion = User::checkPermission();
?>

<?php $__env->startSection('css'); ?>
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css' )); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css' )); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css' )); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
          
        <div class="aiz-titlebar text-left mb-3">
            <div class="row align-items-center">
                <div class="col-auto">
                    <h1 class="h3">All Roles</h1>
                </div>
                <?php if(Auth::user()->user_type == 'admin' || in_array('6', $totalPermissnion)): ?>
                <div class="col text-right">
                    <a href="<?php echo e(route('role.create')); ?>" class="btn btn-circle btn-info">
                        <span>Add New Role</span>
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php echo $__env->make('errors.error_massege', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
          <div class="col-12">

            <div class="card mt-3">
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Role Name</th>
                        <th scope="col">Permission Name</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                  <tbody>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($loop->index+1); ?></th>
                        <td><?php echo e($role->name); ?></td>
                        <td>
                            <select class="form-control">
                                <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option><?php echo e($permission->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                               
                        </td>
                        <td class="d-flex justify-content-center">
                            <?php if(Auth::user()->user_type == 'admin' || in_array('8', $totalPermissnion)): ?>
                            <a href="<?php echo e(route('role.edit', $role->id)); ?>" type="button" class="btn btn-info mr-2">Edit</a>
                            <?php endif; ?>
                            <?php if(Auth::user()->user_type == 'admin' || in_array('9', $totalPermissnion)): ?>
                            <a class="btn btn-danger text-white" href="<?php echo e(route('role.destroy', $role->id)); ?>"
                                onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($role->id); ?>').submit();">
                                    Delete
                            </a>
                            <form id="delete-form-<?php echo e($role->id); ?>" action="<?php echo e(route('role.destroy', $role->id)); ?>" method="POST" style="display: none;">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- DataTables  & Plugins -->
<script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/dataTables.responsive.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/dataTables.buttons.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jszip/jszip.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/pdfmake/pdfmake.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/pdfmake/vfs_fonts.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.html5.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.print.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.colVis.min.js' )); ?>"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datagate/accounts.datagatebd.com/resources/views/backend/staffs/role/index.blade.php ENDPATH**/ ?>