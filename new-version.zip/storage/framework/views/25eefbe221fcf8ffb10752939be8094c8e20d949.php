<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="text-left mb-3">
    <div class="row align-items-center">
        <div class="col-auto">
            <h1 class="h3">All Payment</h1>
        </div>
    </div>
</div>
<div class="row">
	<div class="col-md-4">
        <div class="card">
			<div class="card-header">
				<h5 class="mb-0 h6">Get Payment</h5>
			</div>
			<div class="card-body">
                <form action="<?php echo e(route('get-paymet.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Payment Project</label>
                        <select class="form-control multiple_select" name="project_id" required>
                            <option value=""></option>
                            <?php $__currentLoopData = $all_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="name">Payment Date</label>
                        <input type="date" name="payment_date" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="name">Payment Amount <small>number only</small></label>
                        <input type="number" name="amount" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="name">Payment Method</label>
                        <select class="form-control" name="method" required>
                            <option value="Cahs-on">Cahs-on</option>
                            <option value="Check">Check</option>
                            <option value="bKash">bKash</option>
                            <option value="Nagad">Nagad</option>
                            <option value="Roket">Roket</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="name">Payment Document</label>
                        <input type="file" name="document[]" class="form-control">
                    </div>
                    <div class="form-group mb-3 text-right">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
			</div>
		</div>
	</div>
	<div class="col-md-4">
        <div class="card">
			<div class="card-header">
				<h5 class="mb-0 h6">Supplier Payment</h5>
			</div>
			<div class="card-body">
                <form action="<?php echo e(route('project.expenses.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="type" class="form-control" value="supplier">
                    <div class="form-group">
                        <label for="name">Payment Project</label>
                        <select class="form-control multiple_select" name="project_id" required>
                            <option value=""></option>
                            <?php $__currentLoopData = $all_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="name">Supplier name</label>
                        <select class="form-control multiple_select" name="worker_supplier" required>
                            <option value=""></option>
                            <?php $__currentLoopData = $all_supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="name">Payment Date</label>
                        <input type="date" name="date" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="name">Payment Amount <small>number only</small></label>
                        <input type="number" name="amount" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="name">Payment Method</label>
                        <select class="form-control" name="method" required>
                            <option value="Cahs-on">Cahs-on</option>
                            <option value="Check">Check</option>
                            <option value="bKash">bKash</option>
                            <option value="Nagad">Nagad</option>
                            <option value="Roket">Roket</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="name">Payment Document</label>
                        <input type="file" name="document[]" class="form-control">
                    </div>
                    <div class="form-group mb-3 text-right">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
			</div>
		</div>
	</div>
	<div class="col-md-4">
		<div class="card">
			<div class="card-header">
				<h5 class="mb-0 h6">Worker Payment</h5>
			</div>
			<div class="card-body">
                <form action="<?php echo e(route('project.expenses.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="type" class="form-control" value="worker">
                    <div class="form-group">
                        <label for="name">Payment Project</label>
                        <select class="form-control multiple_select" name="project_id" required>
                            <option value=""></option>
                            <?php $__currentLoopData = $all_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="name">Worker name</label>
                        <select class="form-control multiple_select" name="worker_supplier" required>
                            <option value=""></option>
                            <?php $__currentLoopData = $all_worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($worker->id); ?>"><?php echo e($worker->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="name">Payment Date</label>
                        <input type="date" name="date" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="name">Payment Amount <small>number only</small></label>
                        <input type="number" name="amount" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="name">Payment Method</label>
                        <select class="form-control" name="method" required>
                            <option value="Cahs-on">Cahs-on</option>
                            <option value="Check">Check</option>
                            <option value="bKash">bKash</option>
                            <option value="Nagad">Nagad</option>
                            <option value="Roket">Roket</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="name">Payment Document</label>
                        <input type="file" name="document[]" class="form-control">
                    </div>
                    <div class="form-group mb-3 text-right">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/datagate/accounts.datagatebd.com/resources/views/backend/project/interior/payment.blade.php ENDPATH**/ ?>